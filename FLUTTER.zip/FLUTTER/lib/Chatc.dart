import 'dart:convert';

import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:covidpositivenew/raised_gradient_button.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Chatc extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHomePage(title: 'Flutter Demo Home Page');
  }
}
SharedPreferences localStorage;
String fever="";
class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  AudioPlayer advancedPlayer;

  Future loadMusic() async {
    advancedPlayer = await AudioCache().play("c3.mp3");
  }
  @override
  void initState() {
    super.initState();
    loadMusic();
initShared() async {
  localStorage = await SharedPreferences.getInstance();
}
initShared();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Voice Assistant"),
      ),
      body:  Stack(
        children: <Widget>[
      Column(
      mainAxisAlignment: MainAxisAlignment.center,

        children: <Widget>[
          Expanded(
              child: Image.asset(
                'assets/home_bg.png',
                fit: BoxFit.cover,
                width: double.infinity,
              )),
        ],
      ), Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(padding: EdgeInsets.only(top: 8)),
            Text(
              "Please select your Symptoms",
              style: TextStyle(color: Colors.blue,fontSize: 18.0, fontWeight: FontWeight.w800),
            ),
            Padding(padding: EdgeInsets.only(top: 8)),
            CheckboxWidget(),

          ],
        ),
      ),])
    );
  }

}
var tmpArray = [];
class CheckboxWidget extends StatefulWidget {
  @override
  CheckboxWidgetState createState() => new CheckboxWidgetState();
}

class CheckboxWidgetState extends State {

  Map<String, bool> values = {
    'Dry Cough': false,
    'Loss of Smell': false,
    'Sore Throat': false,
    'Weakness': false,
    'Change in Appetite': false,
    'None': false,
  };



  getCheckboxItems(){

    values.forEach((key, value) {
      if(value == true)
      {
fever="true";
        tmpArray.add(key);
      }
    });

    // Printing all selected items on Terminal screen.
    print(tmpArray);
    // Here you will get all your selected Checkbox items.

    // Clear array after use.
    setState(() {

    });
  }

  @override
  void initState() {
//getCheckboxItems();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column (children: <Widget>[


        Expanded(
          child :SizedBox(
        height: MediaQuery.of(context).size.height/2,
        child:
          ListView(
            children: values.keys.map((String key) {
              return new CheckboxListTile(
                title: new Text(key),
                value: values[key],
                activeColor: Colors.pink,
                checkColor: Colors.white,
                onChanged: (bool value) {
                  setState(() {
                    if(key=="None") {
                      values.forEach((key, value) {
                        values[key] = false;
                      });
                    }
                    print("jis");
                    values[key] = value;
                  });
                },
              );
            }).toList(),
          ),),
        ), Padding(
          padding: const EdgeInsets.only(bottom:150.0),
          child: RaisedGradientButton(
            child: Text('Next',
              style: TextStyle(color: Colors.white),
            ),

            gradient: LinearGradient(
              colors: <Color>[Color(0xff13007D), Color(0xff02A0C7)],
            ),
            width: MediaQuery.of(context).size.width/1.2,
            height: 60,
            borderRadius: 10,
            onPressed: _validate,
          ),
        )]),
    );
  }

  Future _validate() async{
    getCheckboxItems();
    if(fever==""){
      Fluttertoast.showToast(
          msg: "Please Enter Valid Data..",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red
      );


    }
    else {

      localStorage.setString("tmmpa", json.encode(tmpArray).toString());

      Navigator.of(context).pushReplacementNamed('/chatd');


    }
  }

}