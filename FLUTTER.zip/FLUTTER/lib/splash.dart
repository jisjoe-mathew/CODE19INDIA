import 'dart:math';

import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:barcode_scan/barcode_scan.dart';
import 'package:covidpositivenew/raised_gradient_button.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:simple_animations/simple_animations.dart';
import 'package:xml/xml.dart' as xml;


import 'example.dart';
SharedPreferences localStorage;

class ParticleBackgroundApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(children: <Widget>[
      Positioned.fill(child: AnimatedBackground()),
      Positioned.fill(child: Particles(30)),
      Positioned.fill(child: CenteredText()),
    ]);
  }
}

class Particles extends StatefulWidget {
  final int numberOfParticles;

  Particles(this.numberOfParticles);

  @override
  _ParticlesState createState() => _ParticlesState();
}

class _ParticlesState extends State<Particles> {
  final Random random = Random();

  final List<ParticleModel> particles = [];


  initState(){

    List.generate(widget.numberOfParticles, (index) {
      particles.add(ParticleModel(random));
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Rendering(
      startTime: Duration(seconds: 30),
      onTick: _simulateParticles,
      builder: (context, time) {
        return CustomPaint(
          painter: ParticlePainter(particles, time),
        );
      },
    );
  }

  _simulateParticles(Duration time) {
    particles.forEach((particle) => particle.maintainRestart(time));
  }
}

class ParticleModel {
  Animatable tween;
  double size;
  AnimationProgress animationProgress;
  Random random;

  ParticleModel(this.random) {
    restart();
  }

  restart({Duration time = Duration.zero}) {
    final startPosition = Offset(-0.2 + 1.4 * random.nextDouble(), 1.2);
    final endPosition = Offset(-0.2 + 1.4 * random.nextDouble(), -0.2);
    final duration = Duration(milliseconds: 3000 + random.nextInt(6000));

    tween = MultiTrackTween([
      Track("x").add(
          duration, Tween(begin: startPosition.dx, end: endPosition.dx),
          curve: Curves.easeInOutSine),
      Track("y").add(
          duration, Tween(begin: startPosition.dy, end: endPosition.dy),
          curve: Curves.easeIn),
    ]);
    animationProgress = AnimationProgress(duration: duration, startTime: time);
    size = 0.2 + random.nextDouble() * 0.4;
  }

  maintainRestart(Duration time) {
    if (animationProgress.progress(time) == 1.0) {
      restart(time: time);
    }
  }
}

class ParticlePainter extends CustomPainter {
  List<ParticleModel> particles;
  Duration time;

  ParticlePainter(this.particles, this.time);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withAlpha(50);

    particles.forEach((particle) {
      var progress = particle.animationProgress.progress(time);
      final animation = particle.tween.transform(progress);
      final position =
      Offset(animation["x"] * size.width, animation["y"] * size.height);

      canvas.drawCircle(position, size.width * 0.2 * particle.size, paint);
    });
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class AnimatedBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final tween = MultiTrackTween([
      Track("color1").add(Duration(seconds: 3),
          ColorTween(begin: Color(0xff8a113a), end: Colors.lightBlue.shade900)),
      Track("color2").add(Duration(seconds: 3),
          ColorTween(begin: Color(0xff440216), end: Colors.blue.shade600))
    ]);

    return ControlledAnimation(
      playback: Playback.MIRROR,
      tween: tween,
      duration: tween.duration,
      builder: (context, animation) {
        return Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [animation["color1"], animation["color2"]])),
        );
      },
    );
  }
}

class CenteredText extends StatefulWidget {
  @override
  _ScanState createState() => new _ScanState();
}

class _ScanState extends State<CenteredText> {
  String barcode = "";
  AudioPlayer advancedPlayer;

  Future loadMusic() async {
    advancedPlayer = await AudioCache().play("welcome.mp3");
  }
  @override
  void initState() {
    super.initState();
    loadMusic();

    setState(() {

    });
  }
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Align(
          alignment: Alignment.center,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,


            children: <Widget>[

              Center(
                child: Image(
                  image: AssetImage("assets/logo.png"),
                  height: 150.0,
                  width: 150.0,
                ),),
    Padding(
      padding: const EdgeInsets.only(top:12.0),
      child: Text(
      "Welcome to Covid+Ve",
      style: TextStyle(color: Colors.white,fontSize: 20.0, fontWeight: FontWeight.w800),
      ),
    ),
              Padding(
                padding: const EdgeInsets.only(top:12.0),
                child: RaisedGradientButton(
    child: Text('Scan AADHAR QR to Login',
    style: TextStyle(color: Colors.white),
    ),

    gradient: LinearGradient(
    colors: <Color>[Color(0xff13007D), Color(0xff02A0C7)],
    ),
    width: MediaQuery.of(context).size.width/1.2,
    height: 60,
    borderRadius: 10,
    onPressed: scan,
    )
              )

            ],
          ),
        ),


    );


  }
  Future scan() async {

      String barcode = await BarcodeScanner.scan();
      var document = xml.parse(barcode);
      var allStringElements = document.findAllElements('PrintLetterBarcodeData');

      var data="";
      var details = new Map();

      // or do something useful with the whole list
      for (var element in allStringElements) {

        for (var elementa in element.attributes) {
          print('${elementa.toString().substring(0, elementa.toString().indexOf('='))}->${elementa.value}');
          data=data+'${elementa.toString().substring(0, elementa.toString().indexOf('='))}->${elementa.value}'+'\n';
          details[elementa.toString().substring(0, elementa.toString().indexOf('='))]=elementa.value;
        }
      }
      print(details["uid"]);


      if(details!=""){
        localStorage.setString('uid', details["uid"].toString());
        localStorage.setString('name', details["name"].toString());
        localStorage.setString('gender', details["gender"].toString());
        localStorage.setString('yob', details["yob"].toString());
        localStorage.setString('gname', details["gname"].toString());
        localStorage.setString('house', details["house"].toString());
        localStorage.setString('lm', details["lm"].toString());
        localStorage.setString('vtc', details["vtc"].toString());
        localStorage.setString('po', details["po"].toString());
        localStorage.setString('dist', details["dist"].toString());
        localStorage.setString('state', details["state"].toString());
        localStorage.setString('pc', details["pc"].toString());
        localStorage.setBool('aadhar', true);

print("-------------------");
Navigator.of(context).pop();
        Navigator.of(context).pushReplacementNamed('/loginpage');
      }
      setState(() => this.barcode = data.toString());
    }

}

class ParticleBackgroundDemo extends StatefulWidget {
  @override
  _ParticlesStates createState() => _ParticlesStates();
}

class _ParticlesStates extends State<ParticleBackgroundDemo> {

  initState() {
    setS() async {
      //SharedPreferences.setMockInitialValues({});
      localStorage = await SharedPreferences.getInstance();
      if(localStorage.getBool("plogin")){
        Navigator.of(context).pop();
        Navigator.of(context).pushReplacementNamed('/homepage');
      }else
      if (localStorage.getBool("aadhar")) {
        Navigator.of(context).pop();
        Navigator.of(context).pushReplacementNamed('/loginpage');
      }
    }
    setS();
  }
  @override
  Widget build(BuildContext context) {
    return ExamplePage(
      title: "Particle Background",
      pathToFile: "particle_background.dart",
      delayStartup: false,
      builder: (context) => ParticleBackgroundApp(),
    );
  }
}