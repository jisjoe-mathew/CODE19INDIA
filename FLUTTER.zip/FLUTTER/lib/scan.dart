import 'dart:async';

import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:barcode_scan/barcode_scan.dart';
import 'package:covidpositivenew/LoginApp.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:xml/xml.dart' as xml;

import 'Homepage.dart';
SharedPreferences localStorage;

class ScanScreen extends StatefulWidget {
  @override
  _ScanState createState() => new _ScanState();
}

class _ScanState extends State<ScanScreen> {
  String barcode = "";
  AudioPlayer advancedPlayer;

  Future loadMusic() async {
    advancedPlayer = await AudioCache().play("welcome.mp3");
  }
  @override
  void initState() {
    super.initState();
    loadMusic();
    setS() async {
      SharedPreferences.setMockInitialValues({});
      localStorage = await SharedPreferences.getInstance();
    }
    setS();
setState(() {

});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
          appBar: new AppBar(
            title: new Text('Scan Aadhar to Login'),
          ),
          body: new Center(
            child: new Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  child: RaisedButton(
                      color: Colors.blue,
                      textColor: Colors.white,
                      splashColor: Colors.blueGrey,
                      onPressed: scan,
                      child: const Text('START CAMERA SCAN')
                  ),
                )
                ,
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  child: Text(barcode, textAlign: TextAlign.center,),
                )
                ,
              ],
            ),
          ),
    );
  }

  Future scan() async {
    try {
      String barcode = await BarcodeScanner.scan();
      var document = xml.parse(barcode);
      var allStringElements = document.findAllElements('PrintLetterBarcodeData');

      var data="";
      var details = new Map();

      // or do something useful with the whole list
      for (var element in allStringElements) {

        for (var elementa in element.attributes) {
          print('${elementa.toString().substring(0, elementa.toString().indexOf('='))}->${elementa.value}');
          data=data+'${elementa.toString().substring(0, elementa.toString().indexOf('='))}->${elementa.value}'+'\n';
          details[elementa.toString().substring(0, elementa.toString().indexOf('='))]=elementa.value;
        }
      }
print(details["uid"]);


      if(details!=""){
        localStorage.setString('uid', details["uid"].toString());
        localStorage.setString('name', details["name"].toString());
        localStorage.setString('gender', details["gender"].toString());
        localStorage.setString('yob', details["yob"].toString());
        localStorage.setString('gname', details["gname"].toString());
        localStorage.setString('house', details["house"].toString());
        localStorage.setString('lm', details["lm"].toString());
        localStorage.setString('vtc', details["vtc"].toString());
        localStorage.setString('po', details["po"].toString());
        localStorage.setString('dist', details["dist"].toString());
        localStorage.setString('state', details["state"].toString());
        localStorage.setString('pc', details["pc"].toString());
        localStorage.setBool('aadhar', true);


        Navigator.of(context).pop();
  Navigator.of(context).pushReplacementNamed('/loginpage');
}
      setState(() => this.barcode = data.toString());
    } on PlatformException catch (e) {
      if (e.code == BarcodeScanner.CameraAccessDenied) {
        setState(() {
          this.barcode = 'The user did not grant the camera permission!';
        });
      } else {
        setState(() => this.barcode = 'Unknown error: $e');
      }
    } on FormatException{
      setState(() => this.barcode = 'null (User returned using the "back"-button before scanning anything. Result)');
    } catch (e) {
      setState(() => this.barcode = 'Unknown error: $e');
    }
  }
}