import 'package:covidpositivenew/raised_gradient_button.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MyHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHomePage(title: 'Flutter Demo Home Page');
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  void logoff() async {
   SharedPreferences preferences = await SharedPreferences.getInstance();
    preferences.clear();
    Navigator.pushNamedAndRemoveUntil(
        context, '/splash', ModalRoute.withName('/splash'));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Welcome Home"),
      ),
      body: Center(
        child:
        Stack(
          children: <Widget>[
            Column(
              mainAxisAlignment: MainAxisAlignment.center,

              children: <Widget>[
                Expanded(
                    child: Image.asset(
                      'assets/home_bg.png',
                      fit: BoxFit.cover,
                      width: double.infinity,
                    )),
              ],
            ),
            Center(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,

                  children: <Widget>[
                    RaisedGradientButton(
                      child: Text('Chat with Assistant (Symptoms)',
                        style: TextStyle(color: Colors.white),
                      ),

                      gradient: LinearGradient(
                        colors: <Color>[Color(0xff13007D), Color(0xff02A0C7)],
                      ),
                      width: MediaQuery.of(context).size.width/1.2,
                      height: 60,
                      borderRadius: 10,
                      onPressed: ()  {
                        Navigator.of(context).pushNamed('/chata');
                      },
                    ),
                    Padding(
                      padding: EdgeInsets.only(top:12.0),
                    ),
                    RaisedGradientButton(
                      child: Text('Check with your Routes',
                        style: TextStyle(color: Colors.white),
                      ),

                      gradient: LinearGradient(
                        colors: <Color>[Color(0xff13007D), Color(0xff02A0C7)],
                      ),
                      width: MediaQuery.of(context).size.width/1.2,
                      height: 60,
                      borderRadius: 10,
                      onPressed: ()  {
                        Navigator.of(context).pushNamed('/routeapp');
                      },
                    ),
                    Padding(
                      padding: EdgeInsets.only(top:12.0),
                    ),    RaisedGradientButton(
                      child: Text('Logoff',
                        style: TextStyle(color: Colors.white),
                      ),

                      gradient: LinearGradient(
                        colors: <Color>[Color(0xff13007D), Color(0xff02A0C7)],
                      ),
                      width: MediaQuery.of(context).size.width/1.2,
                      height: 60,
                      borderRadius: 10,
                      onPressed: logoff,
                    ),
                    Padding(
                      padding: EdgeInsets.only(top:12.0),
                    ),

                  ]),
            )
          ],
        ),
      ),
    );
  }
}