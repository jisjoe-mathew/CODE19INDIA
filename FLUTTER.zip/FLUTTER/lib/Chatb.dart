import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:covidpositivenew/raised_gradient_button.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Chatb extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MyHomePage(title: 'Flutter Demo Home Page');
  }
}
SharedPreferences localStorage;
enum PatientGender { Normal, Fever, High }
PatientGender _patientGender = PatientGender.Normal;
String fever="Normal";
class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController age=new TextEditingController();
  AudioPlayer advancedPlayer;

  Future loadMusic() async {
    advancedPlayer = await AudioCache().play("c2.mp3");
  }
  @override
  void initState() {
    super.initState();
    loadMusic();
initShared() async {
  localStorage = await SharedPreferences.getInstance();
}
initShared();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Voice Assistant"),
      ),
      body: Center(
          child:
          Stack(
            children: <Widget>[
          Column(
          mainAxisAlignment: MainAxisAlignment.center,

            children: <Widget>[
              Expanded(
                  child: Image.asset(
                    'assets/home_bg.png',
                    fit: BoxFit.cover,
                    width: double.infinity,
                  )),
            ],
          ),
          Center(
          child: Padding(
          padding: const EdgeInsets.all(10.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
        Text(
        "Please select your body Temperature",
        style: TextStyle(color: Colors.blue,fontSize: 18.0, fontWeight: FontWeight.w800),
      ),
      Padding(padding: EdgeInsets.only(top: 12)), Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(padding: EdgeInsets.only(top: 8)),
            Padding(padding: EdgeInsets.only(top: 8)),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Radio(
                  value: PatientGender.Normal,
                  groupValue: _patientGender,
                  onChanged: (PatientGender value){
                    setState(() {
                      _patientGender = value;
                      fever="Normal";
                    });
                  },
                ),
                Text(
                  'Normal',
                  style: new TextStyle(fontSize: 16.0),
                ),
                Radio(
                  value: PatientGender.Fever,
                  groupValue: _patientGender,
                  onChanged: (PatientGender value){
                    setState(() {
                      _patientGender = value;
                      fever="Fever (98-102 F)";
                    });
                  },
                ),
                Text(
                  'Fever',
                  style: new TextStyle(
                    fontSize: 16.0,
                  ),
                ),
                Radio(
                  value: PatientGender.High,
                  groupValue: _patientGender,
                  onChanged: (PatientGender value){
                    setState(() {
                      _patientGender = value;
                      fever="High Fever";
                    });
                  },
                ),
                Text(
                  'High Fever >102 F',
                  style: new TextStyle(fontSize: 16.0),
                ),
              ],
            ),
            RaisedGradientButton(
              child: Text('Next',
                style: TextStyle(color: Colors.white),
              ),

              gradient: LinearGradient(
                colors: <Color>[Color(0xff13007D), Color(0xff02A0C7)],
              ),
              width: MediaQuery.of(context).size.width/1.2,
              height: 60,
              borderRadius: 10,
              onPressed: _validate,
            )
          ],
        ),
      )]),))]))
    );
  }
  Future _validate() async{
    if(fever==""){
      Fluttertoast.showToast(
          msg: "Please Enter Valid Data..",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red
      );


    }
    else {

localStorage.setString("fever", fever.toString());

Navigator.of(context).pushReplacementNamed('/chatc');


    }
  }
}