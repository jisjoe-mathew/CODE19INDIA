import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';



class WelcomePage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
          child: Stack(
            children: <Widget>[
              Column(
                children: <Widget>[
                  Expanded(
                      child: Image.asset(
                        'assets/home_bg.png',
                        fit: BoxFit.cover,
                        width: double.infinity,
                      ))
                ],
              ),
              ContentPage(),
            ],

          ),
        )
    );
  }
}

class ContentPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(top: 10),
        child: Column(
          children: <Widget>[
            CarouselSlider(
              autoPlay: true,
              autoPlayInterval: Duration(seconds: 4),
              enableInfiniteScroll: false,

              initialPage: 0,
              reverse: false,
              viewportFraction: 1.0,
              aspectRatio: MediaQuery.of(context).size.aspectRatio,
              height: MediaQuery.of(context).size.height - 10,
              items: [0, 1, 2, 3, 4, 5].map((i) {
                return Builder(
                  builder: (BuildContext context) {
                    return Container(
                        width: MediaQuery.of(context).size.width,
                        child: AppItro(i));
                  },
                );
              }).toList(),
            ),
          ],
        ));
  }
}

class AppItro extends StatefulWidget {
  int index;
  AppItro(this.index);
  @override
  _AppItroState createState() => _AppItroState();
}

class _AppItroState extends State<AppItro> {
  List<String> imagePath = [
    "assets/splash1.png",
    "assets/splash2.png",
    "assets/splash3.png",
    "assets/splash4.png",
    "assets/splash5.png",
    "assets/splash6.png",
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[

        Container(
          // width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height - 80,
          child: Column(
            children: <Widget>[
              Image.asset(imagePath[widget.index],
                width: MediaQuery.of(context).size.width ,
                height: MediaQuery.of(context).size.height-80,

              ),

            ],
          ),
        ),
        Container(
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.symmetric(horizontal: 24),
          height: 20,
          child: Stack(

            children: <Widget>[
              Dots(widget.index),
              Center(
                  child: FlatButton(onPressed: (){
                    Navigator.pushNamedAndRemoveUntil(
                        context, '/filechoose', ModalRoute.withName('/filechoose'));
                  }, child: Text(
                    widget.index == 5 ? "DONE" : "SKIP",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ))
              ),


            ],
          ),
        )

      ],
    );
  }
}
class Dots extends StatefulWidget {
  int index;
  Dots(this.index);
  @override
  _DotsState createState() => _DotsState();
}

class _DotsState extends State<Dots> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // print("deneme" + currentPage.toString());
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      scrollDirection: Axis.horizontal,
      itemCount: 6,
      itemBuilder: (context, int index) {
        return Container(
            margin: EdgeInsets.only(right: index != 5 ? 4 : 0),
            width: 10,
            height: 10,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: index == widget.index ? Color(0xfff85229) : Colors.white,
                border: Border.all(color: Color(0xfff85229))));
      },
    );
  }
}
